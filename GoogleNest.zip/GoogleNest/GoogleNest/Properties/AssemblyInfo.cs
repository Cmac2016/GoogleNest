﻿using System.Reflection;

[assembly: AssemblyTitle("GoogleNest")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("GoogleNest")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

